from unicodedata import name
from csv import __version__
import setuptools

with open("README.md", 'r', encoding='utf-8') as f:
    long_description = f.read()

__version__ = "0.0.0"

REPO_NAME = "Chest-Cancer-Classifier"
AUTHOR_USER_NAME = "ShlokBagwe"
SRC_REPO = "ChestCancer"
AUTHOR_EMAIL = "shlokbagwe.tech@gmail.com"

setuptools.setup(
    name = SRC_REPO,
    __version__ = __version__,
    author = AUTHOR_USER_NAME,
    author_email = AUTHOR_EMAIL,
    description = "CNN based Classifier for Chest Cancer",
    long_description = long_description,
    long_description_content = "text/markdown",
    url = f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}",
    project_urls={
        "Bug Tracker": f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}/issues",
    },
    package_dir={"": "src"},
    packages=setuptools.find_packages("src")
)

