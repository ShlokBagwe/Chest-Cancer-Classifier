# Chest Cancer Classifier - Project Journey & Progress Summary

## 📌 Project Overview
This project is an **End-to-End Deep Learning & MLOps System** to classify chest cancer from CT-Scan images using a Convolutional Neural Network (CNN).

The goal is to build an industry-standard, production-grade system:
- **Modular, decoupled coding** (Entity $\rightarrow$ Config $\rightarrow$ Component $\rightarrow$ Pipeline).
- **Automated pipelines** tracked with **DVC** (Data Version Control).
- **Experiment tracking & Model Registry** using **MLflow** and **DagsHub**.
- **Deployment-ready web application** (Flask/FastAPI & Docker).

---

## 🏗️ The 7-Step Modular Workflow Followed For Every Stage
For every phase of the project (Ingestion, Model Preparation, Training, Evaluation), we follow a strict, disciplined industry standard:
1. **Update `config/config.yaml`**: Define paths and remote URLs.
2. **Update `params.yaml`**: Define hyperparameters.
3. **Update `entity/config_entity.py`**: Define return types using `@dataclass(frozen=True)`.
4. **Update `config/configuration.py`**: Create the `ConfigManager` to load settings into dataclasses.
5. **Update `components/`**: Write the core logic (e.g., downloading, training).
6. **Update `pipeline/`**: Create the stage pipeline runner (e.g., `stage_01_data_ingestion.py`).
7. **Update `main.py`** and **`dvc.yaml`**: Connect the stage to the master runner and DVC pipeline.

---

## 🚀 What Has Been Done So Far

### 1. Automated Project Structure (`template.py`)
- Automated creation of the entire production skeleton:
  - `src/ChestCancer/`: Main package (components, pipelines, configs, entities, utils, constants).
  - `config/`: Central YAML configurations.
  - `research/`: Notebook sandbox to test each stage before modularizing.
  - `MLOPS_Tool/`: Sandbox environment for testing MLOps tools.

---

### 2. Python Packaging & Clean Imports (`setup.py`)
- Configured local packaging using `setuptools`:
  - `package_dir={"": "src"}` and `find_packages("src")`.
  - Enables clean, professional imports from anywhere in the codebase:
    ```python
    from ChestCancer import logger
    from ChestCancer.utils.common import read_yaml, get_size
    from ChestCancer.entity.config_entity import DataIngestionConfig
    ```

---

### 3. Centralized Logging System (`src/ChestCancer/__init__.py`)
- Custom logging system that writes timestamped logs simultaneously to:
  1. **Terminal console** (live progress tracking).
  2. **`logs/running_logs.log`** (persistent tracking for debugging).

---

### 4. Utility Functions & Constants (`utils/common.py` & `constants/`)
- **`read_yaml()`**: Loads `.yaml` files and wraps them in `ConfigBox` for intuitive dot-notation (`config.data_ingestion.root_dir`).
- **`create_directories()`**: Safely creates folders recursively without failing if they exist.
- **`get_size()`**: Calculates file size in KB to monitor downloaded/trained artifacts.
- **`@ensure_annotations`**: Validates data types at runtime to catch mismatches early.
- **`constants/__init__.py`**: Centralized path constants (`CONFIG_FILE_PATH`, `PARAM_FILE_PATH`).

---

### 5. Hands-on MLOps Sandbox Testing (`MLOPS_Tool/`)
Before integrating tools into the core project, we mastered them in a demo environment:
- **MLflow & DagsHub Remote Tracking**:
  - Connected project to remote DagsHub server (`dagshub.init`).
  - Logged hyperparameters, evaluation metrics (`RMSE`, `MAE`, `R2`), and registered models to MLflow Model Registry.
- **DVC (Data Version Control)**:
  - Initialized DVC (`dvc init --subdir`).
  - Configured multi-stage pipelines (`dvc.yaml`) with dependencies (`deps`) and outputs (`outs`) to leverage smart caching.

---

### 6. Dataset Preparation & Ingestion Configuration
- Chest CT-Scan dataset prepared with **850+ images** across `train/`, `valid/`, and `test/` categories.
- Stored as a single compressed archive (`data.zip`) on Google Drive.
- Centralized ingestion paths and Google Drive URL in `config/config.yaml`:
  ```yaml
  artifacts_root: artifacts

  data_ingestion:
    root_dir: artifacts/data_ingestion
    source_URL: https://drive.google.com/file/d/1H4hFsXxeo6i5IavjQ0MeLLRC9CZnf_Hw/view?usp=sharing
    local_data_file: artifacts/data_ingestion/data.zip
    unzip_dir: artifacts/data_ingestion
  ```

---

### 7. Stage 01: Data Ingestion (✅ Fully Modularized & Completed)
Transitioned Data Ingestion from notebook experimentation (`01_data_ingestion.ipynb`) into the production codebase:

1. **Entity (`entity/config_entity.py`)**:
   - `DataIngestionConfig` dataclass storing `root_dir`, `source_URL`, `local_data_file`, and `unzip_dir`.
2. **Configuration (`config/configuration.py`)**:
   - `ConfigManager.get_data_ingestion()` reads `config.yaml`, creates directories, and instantiates `DataIngestionConfig`.
3. **Component (`components/data_ingestion.py`)**:
   - `DataIngestion.download_file()`: Extracts file ID and downloads `data.zip` using `gdown`.
   - `DataIngestion.extract_file()`: Unzips the dataset into `artifacts/data_ingestion/`.
4. **Pipeline Stage (`pipeline/stage_01_data_ingestion.py`)**:
   - `DataIngestionPipeline` orchestrates the stage.
   - Includes standalone `if __name__ == "__main__":` entrypoint so **DVC can execute this stage independently**.
5. **Master Controller (`main.py`)**:
   - Connected `stage_01_data_ingestion` to `main.py` with custom logging and exception handling.

---

### 8. Stage 02: Data Preparation & Label Standardization (✅ Fully Modularized & Completed)
The raw dataset contained one-hot encoded CSV files (`_classes.csv`) with complex clinical sub-staging names (e.g., `adenocarcinoma_left.lower.lobe_T2_N0_M0_Ib`, `squamous.cell.carcinoma_left.hilum_T1_N2_M0_IIIa`). Stage 02 standardizes and organizes the data into standard multi-class folder structures suitable for deep learning pipelines.

1. **Problem Solved & Label Mapping**:
   - Consolidated granular tumor stages into **4 clean primary cancer classes**:
     - `adenocarcinoma`
     - `large_cell`
     - `squamous_cell`
     - `normal`
   - Configured prefix matching rules in `params.yaml`.
2. **Entity (`entity/config_entity.py`)**:
   - `DataPreparationConfig` dataclass storing `root_dir`, `data_dir`, `prepared_dir`, `splits`, and `label_prefixes`.
3. **Configuration (`config/configuration.py`)**:
   - `ConfigManager.get_data_preparation()` reads `config.yaml` and `params.yaml`, creates output directories, and bundles configuration into `DataPreparationConfig`.
4. **Component (`components/data_preparation.py`)**:
   - `read_csv()`: Reads the split-specific `_classes.csv`.
   - `add_type()`: Uses `iloc[:, 1:].idxmax(axis=1)` and prefix matching to map one-hot columns to standardized target class labels.
   - `split_data_dir()`: Reorganizes raw images into directory structure:
     `artifacts/data_preparation/prepared/{split}/{class_name}/{image_file}`
   - `prepare_all()`: Iterates over all dataset splits (`train`, `valid`, `test`) with validation and missing file tracking.
5. **Pipeline Stage (`pipeline/stage_02_data_preparation.py`)**:
   - `DataPreparationPipeline` coordinates data preparation with custom logging and independent execution support for DVC.
6. **Master Controller (`main.py`)**:
   - Integrated Stage 02 execution right after Stage 01.

---

### 9. GPU Acceleration & WSL2 Environment Setup (✅ Configured & Verified)
Configured hardware-accelerated deep learning using CUDA and cuDNN on WSL2:
- **Hardware**: NVIDIA GeForce RTX 3050 Laptop GPU (4GB VRAM).
- **Environment**: Miniconda `chest` environment with TensorFlow 2.x GPU support.
- **Dynamic Linker Configuration**: Automated `LD_LIBRARY_PATH` loading via Conda activation scripts (`activate.d/env_vars.sh`) and Jupyter kernel configuration to guarantee GPU availability across CLI runs and notebooks.

---

### 10. Stage 03: Prepare Base Model (🔄 In Progress in Research)
- Experimenting in notebook `research/03_baseline_model_preparation.ipynb`.
- Utilizing **Transfer Learning** with a pretrained **VGG-16** convolutional backbone.
- Configuring base model freezing, custom dense classification head for 4 classes, and saving base & full models to `artifacts/base_line_model/`.

---

## 📊 Pipeline Status Checklist

| Stage | Name | Status |
| :---: | :--- | :---: |
| **01** | **Data Ingestion** | ✅ Completed |
| **02** | **Data Preparation** (Label Mapping & Folder Structuring) | ✅ Completed |
| **03** | **Prepare Base Model** (VGG-16 Backbone) | 🔄 In Progress |
| **04** | **Model Training** | ⏳ Pending |
| **05** | **Model Evaluation with MLflow & DagsHub** | ⏳ Pending |
| **06** | **DVC Pipeline Integration (`dvc.yaml`)** | ⏳ Pending |
| **07** | **Prediction Pipeline & Web Application** | ⏳ Pending |

