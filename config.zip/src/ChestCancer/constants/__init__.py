"""
Stores project-wide constants used across different modules
"""

from pathlib import Path

CONFIG_FILE_PATH = Path("config/config.yaml")
PARAM_FILE_PATH = Path("params.yaml")